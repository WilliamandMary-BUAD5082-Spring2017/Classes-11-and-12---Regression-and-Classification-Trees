rm(list=ls())
require(rpart)
weather<-read.table("myweatherdata.csv",sep=",",header=T)
###Discard unwanted columns
names(weather)
discardcols <- names(weather) %in% c("Date", "Location","RISK_MM")
weather<- weather[!discardcols]
names(weather)
###Build 90% training vector of indices and 10% test data frame named weather.test
set.seed(527)
train<-sample(1:nrow(weather), .9*nrow(weather))
weather.test<-weather[-train,]
###build rpart decision tree
mymodel <- rpart(RainTomorrow ~ .,data=weather[train,],method="class",
      parms=list(split="information"),control=rpart.control(usesurrogate=0,maxsurrogate=0,minsplit=53))
###various info and graphic displays
print(mymodel)
printcp(mymodel)
plot(mymodel)
text(mymodel,pretty=0)
require(rattle)
fancyRpartPlot(mymodel, main="Decision Tree")
asRules(mymodel)
summary(mymodel)
###Tuning Parameters
anothermodel<-rpart(RainTomorrow ~ .,data=weather[train,], method="class", 
	parms=list(split="information"), control=rpart.control(minsplit=10, 
	minbucket=5,maxdepth=20,usesurrogate=0,maxsurrogate=0))
###Building a maximal model
mymodel<-rpart(RainTomorrow~.,data=weather[train,],method="class",
parms=list(split="information"),control=rpart.control(usesurrogate=0,
maxsurrogate=0,cp=0,minbucket=1,minsplit=2))
fancyRpartPlot(mymodel, main="Maximal Decision Tree")
print(mymodel$cptable)
plotcp(mymodel)
grid()
###Pruning the maximal tree to minimize xerror
mymodel$cptable
xerr<-mymodel$cptable[,"xerror"]
minxerr<-which.min(xerr)
mincp<-mymodel$cptable[minxerr,"CP"]
mymodel.prune<-prune(mymodel,cp=mincp)
mymodel.prune$cptable
fancyRpartPlot(mymodel.prune, main="Decision Tree With Minimum C.V. Error")
asRules(mymodel.prune)
###Specifying a Loss Matrix
mymodel.prune<-rpart(RainTomorrow~.,data=weather[train,],method="class",
parms=list(split="information"),control=rpart.control(usesurrogate=0,
maxsurrogate=0,cp=0,minbucket=1,minsplit=2,loss=matrix(c(0,1,10,0), byrow=TRUE, nrow=2)))
###Predict on the test set
mymodel.prune.predict <- predict(mymodel.prune, newdata=weather.test, type="class")
table(weather.test$RainTomorrow, mymodel.prune.predict,dnn=c("Actual", "Predicted"))
round(100*table(weather.test$RainTomorrow, mymodel.prune.predict,dnn=c("% Actual", "% Predicted"))/length(mymodel.prune.predict))


